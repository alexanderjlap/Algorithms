// Name: Alexander Lap
// Date: 03/20/2023
// Course: CS 2223
// Professor: Engling

import java.util.Scanner;

public class DoubleTrouble {
    Scanner keyBoard = new Scanner(System.in);
    int[] gameBoard = {3, 7, 5};
    boolean playerTurn = false;
    boolean gameGoing = true;
    boolean playerLost = false;
    int numTaken = 0;

    public static void main(String[] args) {
        DoubleTrouble doubleTrouble = new DoubleTrouble();
        doubleTrouble.greeting();
        doubleTrouble.screen();
        if (doubleTrouble.playerTurn) {
            while (doubleTrouble.gameGoing) {
                doubleTrouble.playGame();
                doubleTrouble.computerPlays();
            }
        }
        else {
            while (doubleTrouble.gameGoing) {
                doubleTrouble.computerPlays();
                doubleTrouble.playGame();
            }
        }
        doubleTrouble.printWinner();
    }
    void runRandComputer() {
        int firstRow = gameBoard[0];
        int secondRow = gameBoard[1];
        int row = largestOf(gameBoard[0], gameBoard[1], gameBoard[2]);
        if (firstRow==row) {
            row=0;
        }
        if (secondRow==row) {
            row=1;
        }
        else {
            row=2;
        }
        makeAMove(row, 1);
    }
    int largestOf(int a, int b, int c) {
        int largestRow = 0;
        if (a > largestRow) {
            largestRow = a;
        }
        if (b > largestRow) {
            largestRow = b;
        }
        if (c > largestRow) {
            largestRow = c;
        }
        return largestRow;
    }
    void makeAMove(int row, int numPieces) {
        if(row == 0) {
            gameBoard[0] = gameBoard[0] - numPieces;
            System.out.println("Computer takes " + numPieces + " green.");
            numTaken++;
        } else if(row == 1) {
            gameBoard[1] = gameBoard[1] - numPieces;
            System.out.println("Computer takes " + numPieces + " yellow.");
            numTaken++;
        } else {
            gameBoard[2] = gameBoard[2] - numPieces;
            System.out.println("Computer takes " + numPieces + " orange.");
            numTaken++;
        }
    }
    public void computerPlays() {
        if (gameGoing) {
            playerTurn = false;
            
            int range = gameBoard[0] ^ gameBoard[1] ^ gameBoard[2];
            if (range == 0) {
                runRandComputer();
            } else {
                AI(win());
            }
            System.out.println("Current board");
            System.out.println(gameBoard[0] + " green " + gameBoard[1] + " yellow " + gameBoard[2] + " orange.");
            whoWon();
            playerTurn = true;
        }
    }
    public void AI(String b) {
        if (!b.equals("Bad")) {
            int green = Integer.parseInt(String.valueOf(b.charAt(0)));
            if (green != gameBoard[0]) {
                int diff = gameBoard[0]-green;
                gameBoard[0] = green;
                System.out.println("The computer took " + (diff) + " green markers.");
                numTaken += diff;
            }
            int yellow = Integer.parseInt(String.valueOf(b.charAt(2)));
            if (yellow != gameBoard[1]) {
                int diff = gameBoard[1]-yellow;
                gameBoard[1] = yellow;
                System.out.println("The computer took " + (diff) + " yellow markers.");
                numTaken += diff;
            }
            int orange = Integer.parseInt(String.valueOf(b.charAt(4)));
            if (orange != gameBoard[2]) {
                int diff = gameBoard[2]-orange;
                gameBoard[2] = orange;
                System.out.println("The computer took " + (diff) + " orange markers.");
                numTaken += diff;
            }
        }
        else{
            System.out.println("Error");
        }
    }
    public String win() {
        for (int i = 0; i <= gameBoard[0]; i++) {
            for (int j = 0; j <= gameBoard[1] ; j++) {
                for (int k = 0; k <= gameBoard[2] ; k++) {
                    int now = i^j^k;
                    if (    (now == 0 && i != gameBoard[0] && j == gameBoard[1] && k == gameBoard[2]) ||
                            (now == 0 && i == gameBoard[0] && j != gameBoard[1] && k == gameBoard[2]) ||
                            (now == 0 && i == gameBoard[0] && j == gameBoard[1] && k != gameBoard[2]) ) {
                        return i +" " +j +" " +k +" ";
                    }
                }
            }
        }
        return "Bad";
    }
    public void greeting() {
        System.out.println("Welcome to Double Trouble!");
    }
    public boolean getTurn() {
        return playerTurn;
    }
    
    public void screen() {
        System.out.println("Want to go first? Yes/no");
        String user = keyBoard.next().toLowerCase();
        if (user.equals("yes")){
            playerTurn = true;
        }
        else if (user.equals("no")){
        }
        else{
            screen();
        }
    }
    public void playGame() {
        if (gameGoing) {
            String color = chooseColor();
            int toRemove = 0;
            System.out.println("You chose " + color);
            if (color.equals("green") || color.equals("g")) {
                if (gameBoard[0] != 0) {
                    System.out.println("Choose how many pieces to remove.");
                    toRemove = keyBoard.nextInt();
                    if (gameBoard[0] - toRemove < 0) {
                        System.out.println("There are only " + gameBoard[0] + " green pieces.");
                        playGame();
                    } else if (toRemove == 0) {
                        System.out.println("Can't remove 0 pieces.");
                        playGame();
                    } else {
                        gameBoard[0] -= toRemove;
                        System.out.println("Only " + gameBoard[0] + " green pieces left.");
                        System.out.println("Current board");
                        System.out.println(gameBoard[0] + " green " + gameBoard[1] + " yellow " + gameBoard[2] + " orange.");
                        if (gameGoing) {
                            System.out.println("Computer moves");
                        }
                        whoWon();
                    }
                } else {
                    System.out.println("Only " + gameBoard[0] + " green pieces. Pick another color.");
                    playGame();
                }
            }
            if (color.equals("yellow") || color.equals("y")) {
                if (gameBoard[1] != 0) {
                    System.out.println("Choose how many pieces to remove.");
                    toRemove = keyBoard.nextInt();
                    if (gameBoard[1] - toRemove < 0) {
                        System.out.println("Only " + gameBoard[1] + " yellow pieces.");
                        playGame();
                    } else if (toRemove == 0) {
                        System.out.println("Can't remove 0 pieces.");
                        playGame();
                    } else {
                        gameBoard[1] -= toRemove;
                        System.out.println("Only " + gameBoard[1] + " yellow pieces left.");
                        System.out.println("Current board");
                        System.out.println(gameBoard[0] + " green " + gameBoard[1] + " yellow " + gameBoard[2] + " orange.");
                        if (gameGoing){
                            System.out.println("Computer moves");}
                        whoWon();
                    }
                } else {
                    System.out.println("No yellow pieces. Pick another color.");
                    playGame();
                }
            }
            if (color.equals("orange") || color.equals("o")) {
                if (gameBoard[2] != 0) {
                    System.out.println("Choose how many pieces to remove.");
                    toRemove = keyBoard.nextInt();
                    if (gameBoard[2] - toRemove < 0) {
                        System.out.println("Only " + gameBoard[2] + " orange pieces.");
                        playGame();
                    } else if (toRemove == 0) {
                        System.out.println("Can't remove 0 pieces.");
                        playGame();
                    } else {
                        gameBoard[2] -= toRemove;
                        System.out.println("Only " + gameBoard[2] + " orange pieces left.");
                        System.out.println("Current board");
                        System.out.println(gameBoard[0] + " green " + gameBoard[1] + " yellow " + gameBoard[2] + " orange.");
                        if (gameGoing){
                            System.out.println("Computer moves");}
                        whoWon();
                    }
                } else {
                    System.out.println("No orange pieces. Choose another color.");
                    playGame();
                }
            }
        }
    }
    public String chooseColor() {
        System.out.println("Choose any color");
        String color = "";
        whoWon();
        boolean pause = true;
        while (pause && gameGoing){
            color = keyBoard.next().toString().toLowerCase();
            pause =! acceptable(color);
        }
        return color;
    }
    public boolean acceptable(String color) {
        if (!color.equals("green") && !color.equals("g")  && !color.equals("yellow") && !color.equals("y") && !color.equals("orange") && !color.equals("o") ) {
            System.out.println("Can't accept that color. Choose green, orange, or yellow.");
            return false;
        }
        else {
            return true;
        }
    }
    public void printWinner() {
        if (playerLost) {
            System.out.println("Computer won. It took " + numTaken+" markers.");
        }
        else {
            System.out.println("Congratulations, you won!");
        }
    }
    public void whoWon() {
        if (gameBoard[0] == 0 && gameBoard[1] == 0 && gameBoard[2] == 0 && playerTurn) {
            gameGoing = false;
            playerLost = false;
        }
        if (gameBoard[0] == 0 && gameBoard[1] == 0 && gameBoard[2] == 0 && !playerTurn) {
            gameGoing = false;
            playerLost = true;
        }
    }
}