// Name: Alexander Lap
// Date: 04/20/2023
// Class: CS 2223
// Professor: Engling

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Scanner;

public class SecondProblem {

    public static void main(String[] args) {

        InputStream is = SecondProblem.class.getResourceAsStream("Moby-Dick-Chapter-1-groomed.txt");
        Scanner scanner = new Scanner(is, String.valueOf(StandardCharsets.UTF_8));

        Hashtable<Integer, String> hashedWords = new Hashtable<Integer, String>();
        HashMap<String, Integer> hashValues = new HashMap<String, Integer>();
        int C = 123;
        int m = 1000;

        ArrayList<String> words = new ArrayList<String>();

        while (scanner.hasNext()) {
            String s = scanner.next();
            String formattedString = s.replaceAll("[^'\\-a-zA-Z]*", "");
            words.add(formattedString);
        }

        boolean tableFull = false;
        for (String s : words) {
            int hash = 0;
            for (Character c : s.toCharArray()) {
                hash = (hash * C + (int) (c)) % m;
            }

            int startHash = hash;
            while(hashedWords.get(hash) != null){
                if(s.equals(hashedWords.get(hash))) break;
                ++hash;
                if(startHash == hash){
                    tableFull = true;
                    break;
                }
                if(hash >= 1000){
                    hash = 0;
                }
            }

            if(tableFull) break;

            hashedWords.put(hash, s);

            hashValues.put(s, startHash);
        }


        for(int i = 0; i < 1000; ++i){
            String word = hashedWords.get(i);
            String value = hashValues.get(word) == null ? "null" : hashValues.get(word).toString();
            System.out.println("Hash address: " + i + ", Hashed Word: " + word + ", Hash Value of Word: " + value);
        }
    }
}