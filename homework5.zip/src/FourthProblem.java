// Name: Alexander Lap
// Date: 04/20/2023
// Class: CS 2223
// Professor: Engling

public class FourthProblem {
    static int V = 10;

    int findMinimumDistance(int dist[], boolean sptSet[]) {
        int min = Integer.MAX_VALUE, min_index = -1;

        for (int v = 0; v < V; v++)
            if (!sptSet[v] && dist[v] <= min) {
                min = dist[v];
                min_index = v;
            }
        return min_index;
    }

    void printResult(int dist[], int n, int end) {
        System.out.println("The distance from the source vertex to vertex " + end + " is " + dist[end] + " units.");
    }

    void dijkstraAlgorithm(int graph[][], int source, int end) {
        int dist[] = new int[V];

        boolean sptSet[] = new boolean[V];

        for (int i = 0; i < V; i++) {
            dist[i] = Integer.MAX_VALUE;
            sptSet[i] = false;
        }

        dist[source] = 0;

        for (int count = 0; count < V - 1; count++) {
            int u = findMinimumDistance(dist, sptSet);

            sptSet[u] = true;

            for (int v = 0; v < V; v++)
                if (!sptSet[v] && graph[u][v] != 0 && dist[u] != Integer.MAX_VALUE && dist[u] + graph[u][v] < dist[v])
                    dist[v] = dist[u] + graph[u][v];
        }

        printResult(dist, V, end);
    }

    public static void main(String[] args) {
        int graph[][] = new int[][]{{0, 50, 7, 10, 0, 0, 0, 0, 0, 0},
                {50, 0, 30, 0, 3, 0, 99, 0, 0, 0},
                {7, 30, 0, 6, 27, 15, 0, 0, 0, 0},
                {10, 0, 6, 0, 0, 11, 0, 0, 4, 0},
                {0, 3, 27, 0, 0, 12, 120, 105, 0, 0},
                {0, 0, 15, 11, 12, 0, 0, 119, 5, 0},
                {0, 99, 0, 0, 120, 0, 0, 2, 0, 67},
                {0, 0, 0, 0, 105, 119, 2, 0, 122, 66},
                {0, 0, 0, 4, 0, 5, 0, 122, 0, 190},
                {0, 0, 0, 0, 0, 0, 67, 66, 190, 0}};


        FourthProblem t = new FourthProblem();
        t.dijkstraAlgorithm(graph, 0, 8);
    }
}