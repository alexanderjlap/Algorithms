// Name: Alexander Lap
// Date: 04/20/2023
// Class: CS 2223
// Professor: Engling

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;

public class FirstProblem {

    public static void main(String[] args) {
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        InputStream is = classloader.getResourceAsStream("Moby-Dick-Chapter-1-groomed.txt");
        InputStreamReader streamReader = new InputStreamReader(is, StandardCharsets.UTF_8);

        HashSet<String> words = new HashSet<>();

        try (BufferedReader br = new BufferedReader(streamReader)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] lineWords = line.split("[^'\\-a-zA-Z]+");
                for (String word : lineWords) {
                    if (!word.isEmpty()) {
                        words.add(word.toLowerCase());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("IOException: " + e.getMessage());
            return;
        }

        int C = 123;
        int m = 1000;

        HashMap<Integer, String> hashedWords = new HashMap<>();

        for (String s : words) {
            int hash = 0;
            for (int i = 0; i < s.length(); i++) {
                hash = (hash * C + s.charAt(i)) % m;
            }

            while (hashedWords.containsKey(hash)) {
                hash = (hash + 1) % m;
            }

            hashedWords.put(hash, s);
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < m; i++) {
            if (hashedWords.containsKey(i)) {
                sb.append(i).append(": ").append(hashedWords.get(i)).append("\n");
            }
        }

        System.out.print(sb.toString());
    }
}