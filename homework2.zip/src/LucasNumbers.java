// Name: Alexander Lap
// Date: 03/28/2023
// Class: CS 2223
// Professor: Engling

import java.time.Clock;
import java.util.ArrayList;
import java.time.Instant;

public class LucasNumbers {

    public static void main(String args[]){
        Clock clock = Clock.systemDefaultZone();
        Instant instant = clock.instant();

        int numLucasNumbers = 45;

        ArrayList<Long> times = new ArrayList<Long>();

        System.out.println("The first " + numLucasNumbers + " Lucas numbers are:");
        for (int i=0; i < numLucasNumbers; i++){
            long startTime = clock.millis();
            System.out.print(lucas(i));
            long totalTime = clock.millis() - startTime;
            times.add(totalTime);
            System.out.println(" Time: " + totalTime + "ms");
        }

        System.out.println("The ratios of the following computations are:");
        for(int i = 0; i < times.size() - 1; ++i){
            System.out.println(times.get(i) == 0 ? 0 : (float)times.get(i+1)/(float)times.get(i));
        }
    }

    public static int lucas(int n) {
        if(n == 0) return 2;
        if(n == 1) return 1;
        return lucas(n - 1) + lucas(n - 2);
    }
}