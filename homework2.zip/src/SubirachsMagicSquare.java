// Name: Alexander Lap
// Date: 03/28/2023
// Class: CS 2223
// Professor: Engling

import java.util.Arrays;
import java.util.ArrayList;

public class SubirachsMagicSquare {

    public static int tempCombos = 0;
    public static int numCombos = 0;
    public static int mostNumCombos = 0;
    public static int diffSum = 0;

    public static void main(String[] args){
        Integer[] square = {1, 14, 14, 4, 11, 7, 6, 9, 8, 10, 10, 5, 13, 2, 3, 15};
        int n = square.length;

        System.out.println("Each of the four sets of numbers that add up to the magic number (33):");
        fourElementCombinations(square, n, 33);

        System.out.println("Regardless of length, the following combinations sum up to the magic number (33):");
        sum(new ArrayList<Integer>(Arrays.asList(square)), 33, true);
        System.out.println("Combinations available is " + numCombos);

        numCombos = 0;
        int sum = 0;
        for(int i = 0; i < n; ++i){
            sum += square[i];
        }
        for(int i = 0; i < sum; ++i){
            tempCombos = 0;
            sum(new ArrayList<Integer>(Arrays.asList(square)), i, false);
        }
        System.out.println("There are number of ways to find each sum that is possible: " + numCombos);
        System.out.println("The amount with the most combinations in the sum is " + diffSum + " with " + mostNumCombos + " combinations");
    }

    public static void fourElementCombinations(Integer A[], int n, int X){
        int l, r;

        Arrays.sort(A);

        for (int i = 0; i < n - 3; i++){
            for (int j = i + 1; j < n - 2; j++){
                l = j + 1;
                r = n - 1;

                while (l < r){
                    if (A[i] + A[j] + A[l] + A[r] == X){
                        System.out.println(A[i]+" "+A[j]+" "+A[l]+" "+A[r]);
                        l++;
                        r--;
                    }
                    else if (A[i] + A[j] + A[l] + A[r] < X)
                        l++;
                    else
                        r--;
                }
            }
        }
    }


    public static void sum(ArrayList<Integer> nums, int target, boolean print){
        sumRecursive(nums, target, new ArrayList<Integer>(), print);
    }

    public static void sumRecursive(ArrayList<Integer> nums, int target, ArrayList<Integer> partial, boolean print){
        int sum = 0;
        for(int x : partial) sum += x;

        if(sum == target){
            if(print) System.out.println(Arrays.toString(partial.toArray()));
            ++numCombos;
            ++tempCombos;
            if(tempCombos > mostNumCombos){
                mostNumCombos = tempCombos;
                diffSum = sum;
            }
        }

        if(sum >= target){
            return;
        }

        for(int i = 0; i < nums.size(); ++i){
            ArrayList<Integer> remainders = new ArrayList<Integer>();
            int n = nums.get(i);

            for(int j = i + 1; j < nums.size(); ++j){
                remainders.add(nums.get(j));
            }

            ArrayList<Integer> partialRec = new ArrayList<Integer>(partial);
            partialRec.add(n);

            sumRecursive(remainders, target, partialRec, print);
        }
    }
}