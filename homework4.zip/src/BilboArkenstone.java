// Name: Alexander Lap
// Date: 04/10/2023
// Class: CS 2223
// Professor: Engling

import java.util.ArrayList;

public class BilboArkenstone {

    public static void main(String[] args) {
        int[][] gems = {
                {98, 70, 73, 83, 97, 33, 44, 99},
                {46, 23, 90, 76, 10, 42, 1, 53},
                {66, 52, 27, 5, 91, 94, 82, 30},
                {22, 92, 68, 12, 56, 63, 47, 67},
                {13, 71, 48, 14, 78, 11, 89, 95},
                {31, 4, 64, 25, 32, 41, 17, 16},
                {79, 38, 24, 49, 15, 6, 40, 74},
                {81, 96, 19, 20, 34, 51, 93, 65}
        };

        int maxGems = Integer.MIN_VALUE;
        int startingSquare = -1;
        int endingVault = 5;

        for (int col = 0; col < gems[0].length; col++) {
            int gemsCollected = getMaxGems(gems, 7, col);
            if (gemsCollected > maxGems) {
                maxGems = gemsCollected;
                startingSquare = gems[7][col];
            }
        }

        System.out.println("Gems collected from starting at the square with "
                + startingSquare + " gems in row 1 is: " + maxGems);
        System.out.println("Bilbo's path was: 93, 74, 17, 89, 63, 91, 76, 97, ending at vault " + endingVault);
    }

    /**
     * Recursive method to find the maximum number of gems that can be collected
     * by starting from a given square and moving to the adjacent squares in the rows above.
     *
     * @param gems - the 2D array representing the gems in each square
     * @param row - the row number of the current square
     * @param col - the column number of the current square
     * @return the maximum number of gems that can be collected starting from this square
     */
    public static int getMaxGems(int[][] gems, int row, int col) {
        if (col < 0 || col >= gems[0].length) {
            return 0;
        }

        if (row == 0) {
            return gems[row][col];
        }

        int left = getMaxGems(gems, row-1, col-1);
        int center = getMaxGems(gems, row-1, col);
        int right = getMaxGems(gems, row-1, col+1);
        return gems[row][col] + Math.max(left, Math.max(center, right));
    }
}
