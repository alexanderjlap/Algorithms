// Name: Alexander Lap
// Date: 04/23/2023
// Class: CS 2223
// Professor: Engling

public class AllSolutionsNQueens {
    public static int solutionNumber = 1;

    public static void main(String[] args) {
        int n = 5;

        Integer[][] board = new Integer[n][n];

        zeroBoard(board);

        getSolution(board);
    }

    public static void zeroBoard(Integer[][] board){
        for(int i = 0; i < board.length; ++i){
            for(int j = 0; j < board.length; ++j){
                board[i][j] = 0;
            }
        }
    }

    public static void printBoard(Integer[][] board){
        Integer[] queens = new Integer[board.length];
        System.out.println("\nBoard " + solutionNumber++ + ":");
        for(int i = 0; i < board.length; ++i){
            for(int j = 0; j < board[0].length; ++j){
                System.out.print(board[i][j] + " ");
                if(board[i][j] == 1) queens[i] = j;
            }
            System.out.println();
        }
        System.out.print("(");
        for(int i = 0; i < queens.length; ++i){
            System.out.print((i == queens.length || i == 0 ? (queens[i] + 1) : ", " + (queens[i] + 1)));
        }
        System.out.println(")\n");
    }

    public static boolean isQueenThreatened(Integer[][] board, int row, int col){
        int i, j;

        for(i = 0; i < board.length; ++i){
            if(i != col && board[row][i] == 1) return true;
        }

        for(i = 0; i < row; ++i){
            if(board[i][col] == 1) return true;

        }

        for(i = row, j = col; i >= 0 && j >= 0; --i, --j){
            if(i != row && board[i][j] == 1) return true;

        }

        for(i = row, j = col; j < board.length && i >= 0; --i, ++j){
            if(i != row && board[i][j] == 1) return true;

        }
        return false;
    }

    public static boolean solve(Integer[][] board, int row){
        if(row >= board.length){
            printBoard(board);
            return true;
        }

        boolean answer = false;
        for(int i = 0; i < board.length; ++i){
            if(!isQueenThreatened(board, row, i)){
                board[row][i] = 1;

                answer = (solve(board, row + 1)) || answer;

                board[row][i] = 0;
            }
        }

        return answer;
    }

    public static boolean getSolution(Integer[][] board){
        if(solve(board, 0) == false){
            System.out.println("No solution");
            return false;
        }
        return true;
    }
}