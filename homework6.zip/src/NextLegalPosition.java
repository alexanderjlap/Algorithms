// Name: Alexander Lap
// Date: 04/23/2023
// Class: CS 2223
// Professor: Engling

public class NextLegalPosition {

    public static void main(String[] args) {
        int n = 8;

        Integer[] queenPositions = {1, 6, 8, 3, 7, 0, 0, 0};

        Integer[][] board = initializeBoard(n, queenPositions);

        printBoard(board);

        System.out.println("Next row = " + getNextRow(board, board.length - 1));

        System.out.println("Getting next legal position of board...");
        nextLegalPosition(board, getNextRow(board, board.length - 1));

        System.out.println("Next legal position: ");
        printBoard(board);

    }

    public static Integer[][] initializeBoard(int n, Integer[] queenPositions){
        System.out.println("Initializing board...");
        Integer[][] board = new Integer[n][n];

        for(int i = 0; i < n; ++i){
            for(int j = 0; j < n; ++j){
                board[i][j] = 0;
            }
        }

        for(int i = 0; i < queenPositions.length; ++i){
            int col = queenPositions[i] - 1;

            if(col != -1){
                board[i][col] = 1;
            }
        }

        return board;
    }

    public static void printBoard(Integer[][] board){
        System.out.println("\nBoard:");
        for(int i = 0; i < board.length; ++i){
            for(int j = 0; j < board[0].length; ++j){
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("\n");
    }

    public static boolean isQueenThreatened(Integer[][] board, int row, int col){
        int i, j;


        for(i = 0; i < board.length; ++i){
            if(i != col && board[row][i] == 1) return true;
        }

        for(i = 0; i < row; ++i){
            if(board[i][col] == 1) return true;

        }

        for(i = row, j = col; i >= 0 && j >= 0; --i, --j){
            if(i != row && board[i][j] == 1) return true;

        }

        for(i = row, j = col; j < board.length && i >= 0; --i, ++j){
            if(i != row && board[i][j] == 1) return true;

        }
        return false;
    }

    public static boolean isLegalPosition(Integer[][] board) {
        for(int i = 0; i < board.length; ++i) {
            for (int j = 0; j < board.length; ++j) {
                if (board[i][j] == 1) {
                    if (isQueenThreatened(board, i, j)) return false;
                }
            }
        }
        return true;
    }

    public static int getNextRow(Integer[][] board, int row){
        int answer = row;
        int col = -1;

        for(int i = 0; i < board.length; ++i){
            if(board[row][i] == 1){
                col = i;
            }
        }

        if(col == -1){
            answer = getNextRow(board, row - 1);
        }

        return answer;
    }

    public static int getCol(Integer[][] board, int row){
        for(int i = 0; i < board.length; ++i){
            if(board[row][i] == 1){
                return i;
            }
        }
        return -1;
    }

    public static boolean nextLegalPosition(Integer[][] board, int row){
        int nextRow = getNextRow(board, board.length - 1);

        if(nextRow < board.length - 1 && isLegalPosition(board)){
            return getNextLegalPosition(board, nextRow + 1);
        }

        return getNextLegalPosition(board, nextRow);
    }

    public static boolean getNextLegalPosition(Integer[][] board, int row){

        int col = -1;
        for(int i = 0; i < board.length; ++i){
            if(board[row][i] == 1) col = i;
        }

        if(col == -1){
            for(int i = 0; i < board.length; ++i){
                if(!isQueenThreatened(board, row, i)){
                    board[row][i] = 1;
                    return true;
                }
            }

            int previousRow = getNextRow(board, board.length - 1);
            int previousCol = getCol(board, previousRow);
            board[previousRow][previousCol] = 0;
            return getNextLegalPosition(board, row - 1);
        }

        int qRow = row;
        int qCol = getCol(board, row);
        board[qRow][qCol] = 0;

        for (int i = 0; i < board.length; ++i) {
            if (!isQueenThreatened(board, row, i)) {

                if(i != qCol){
                    board[row][i] = 1;
                    return true;
                }
            }
        }

        return getNextLegalPosition(board, row - 1);
    }
}
