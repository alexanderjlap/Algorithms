// Name: Alexander Lap
// Date: 04/23/2023
// Class: CS 2223
// Professor: Engling

import java.util.Arrays;

public class IsLegalPosition {

    public static void main(String[] args) {
        int n = 8;
        Integer[] queenPositions = {1, 6, 8, 3, 7, 0, 0, 0};
        Integer[][] board = initializeBoard(n, queenPositions);
        printBoard(board);
        System.out.println("Is legal position: " + isLegalPosition(board));
    }

    public static Integer[][] initializeBoard(int n, Integer[] queenPositions){
        System.out.println("Initializing board...");
        Integer[][] board = new Integer[n][n];
        for(int i = 0; i < n; ++i){
            for(int j = 0; j < n; ++j){
                board[i][j] = 0;
            }
        }
        for(int i = 0; i < queenPositions.length; ++i){
            int col = queenPositions[i] - 1;
            if(col != -1){
                board[i][col] = 1;
            }
        }
        return board;
    }

    public static void printBoard(Integer[][] board){
        System.out.println("\nBoard:");
        for(Integer[] row : board){
            System.out.println(Arrays.toString(row));
        }
        System.out.println("\n");
    }

    public static boolean isQueenThreatened(Integer[][] board, int row, int col){
        for(int i = 0; i < board.length; ++i){
            if(i != col && board[row][i] == 1){
                return true;
            }
        }
        for(int i = 0; i < row; ++i){
            if(board[i][col] == 1){
                return true;
            }
        }
        for(int i = row, j = col; i >= 0 && j >= 0; --i, --j){
            if(i != row && board[i][j] == 1){
                return true;
            }
        }
        for(int i = row, j = col; j < board.length && i >= 0; --i, ++j){
            if(i != row && board[i][j] == 1){
                return true;
            }
        }
        return false;
    }

    public static boolean isLegalPosition(Integer[][] board) {
        for(int i = 0; i < board.length; ++i) {
            for (int j = 0; j < board.length; ++j) {
                if (board[i][j] == 1 && isQueenThreatened(board, i, j)) {
                    return false;
                }
            }
        }
        return true;
    }
}
