// Name: Alexander Lap
// Date: 04/23/2023
// Class: CS 2223
// Professor: Engling

public class FirstSolutionNQueens {

    public static void main(String[] args) {
        int n = 15;

        int[] board = new int[n];

        for (int i = 0; i < n; i++) {
            board[i] = -1;
        }

        solve(board, 0);

        if (board[0] == -1) {
            System.out.println("No solution");
        } else {
            printBoard(board);
        }
    }

    public static void printBoard(int[] board) {
        System.out.println("\nBoard:");
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                if (board[i] == j) {
                    System.out.print("1 ");
                } else {
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }
        System.out.print("(");
        for (int i = 0; i < board.length; i++) {
            System.out.print((i == board.length - 1 || i == 0 ? (board[i] + 1) : ", " + (board[i] + 1)));
        }
        System.out.println(")\n");
    }

    public static boolean isSafe(int[] board, int row, int col) {
        for (int i = 0; i < row; i++) {
            if (board[i] == col || Math.abs(board[i] - col) == Math.abs(i - row)) {
                return false;
            }
        }
        return true;
    }

    public static boolean solve(int[] board, int row) {
        if (row >= board.length) {
            return true;
        }
        for (int i = 0; i < board.length; i++) {
            if (isSafe(board, row, i)) {
                board[row] = i;
                if (solve(board, row + 1)) {
                    return true;
                }
                board[row] = -1;
            }
        }
        return false;
    }
}

