// Name: Alexander Lap
// Date: 04/04/2023
// Class: CS 2223
// Professor: Engling

public class EasyInversionCount {
    public static void main(String[] args){
        int[] testArr = new int[]{3, 2, 1};

        System.out.println("Number of inversions in " + printArray(testArr) + " is: " + selectionSort(testArr));
    }

    public static int selectionSort(int arr[]) {
        int n = arr.length;
        int counter = 0;
        for (int i = 0; i < n - 1; ++i) {
            int minIndex = i;
            for (int j = i + 1; j < n; ++j) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                ++counter;
                int temp = arr[i];
                arr[i] = arr[minIndex];
                arr[minIndex] = temp;
            }
        }
        return counter;
    }

    public static String printArray(int[] arr){
        int n = arr.length;
        String answer = "[";
        for (int i=0; i < n; ++i) {
            answer += (arr[i]);
            answer += i == n - 1 ? "" : " ";
        }
        answer += "]";
        return answer;
    }
}
