// Name: Alexander Lap
// Date: 04/04/2023
// Class: CS 2223
// Professor: Engling

public class PalindromeCheck {
    public static void main(String[] args) {
        String test1 = "Never odd or even";
        String test2 = "Able was I ere I saw Elba";
        String test3 = "A man, a plan, a canal: Panama!";
        String test4 = "This is not a palindrome";

        System.out.println("Is '" + test1 + "' a palindrome: " + isPalindrome(test1));
        System.out.println("Is '" + test2 + "' a palindrome: " + isPalindrome(test2));
        System.out.println("Is '" + test3 + "' a palindrome: " + isPalindrome(test3));
        System.out.println("Is '" + test4 + "' a palindrome: " + isPalindrome(test4));
    }

    public static boolean isPalindrome(String text) {
        String modifiedText = text.replaceAll("[^a-zA-Z]", "").toLowerCase();
        String reverseModifiedText = reverse(modifiedText);

        return modifiedText.equals(reverseModifiedText);
    }

    public static String reverse(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = text.length() - 1; i >= 0; i--) {
            sb.append(text.charAt(i));
        }
        return sb.toString();
    }
}
