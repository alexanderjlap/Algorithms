// Name: Alexander Lap
// Date: 04/04/2023
// Class: CS 2223
// Professor: Engling

import java.util.Arrays;

public class FastInversionCounter {
    public static void main(String[] args) {
        int[] testArr1 = new int[]{3, 2, 1};
        int[] testArr2 = new int[]{4, 3, 2, 1, 8, 7, 6 ,5};
        int numInversions1 = countInversions(testArr1);
        int numInversions2 = countInversions(testArr2);
        System.out.println("Number of inversions in " + Arrays.toString(testArr1) + " is: " + numInversions1);
        System.out.println("Number of inversions in " + Arrays.toString(testArr2) + " is: " + numInversions2);
    }

    private static int countInversions(int[] arr) {
        return mergeSortAndCount(arr, 0, arr.length - 1);
    }

    private static int mergeSortAndCount(int[] arr, int left, int right) {
        if (left >= right) {
            return 0;
        }

        int mid = (left + right) / 2;
        int count = mergeSortAndCount(arr, left, mid) + mergeSortAndCount(arr, mid + 1, right);

        int[] tmp = new int[right - left + 1];
        int i = left, j = mid + 1, k = 0;

        while (i <= mid && j <= right) {
            if (arr[i] <= arr[j]) {
                tmp[k++] = arr[i++];
            } else {
                count += mid - i + 1;
                tmp[k++] = arr[j++];
            }
        }

        while (i <= mid) {
            tmp[k++] = arr[i++];
        }

        while (j <= right) {
            tmp[k++] = arr[j++];
        }

        System.arraycopy(tmp, 0, arr, left, tmp.length);

        return count;
    }
}
