// Name: Alexander Lap
// Date: 04/04/2023
// Class: CS 2223
// Professor: Engling

import java.util.ArrayList;
import java.util.HashMap;

public class GrayCodes {

    public static void main(String[] args){
        ArrayList<String> grayCodes = new ArrayList<String>();

        String[] children = new String[]{"Emma", "Frank", "Grace", "Henry"};

        int numChildren = children.length;
        grayCodes = generateGrayCodes(numChildren);

        System.out.println("gray codes for n = " + numChildren + ":");
        for(String s : grayCodes){
            System.out.println(s);
        }
        System.out.println();
        System.out.println();
        System.out.println("Order of moved children: ");
        for(int i = 0; i < grayCodes.size() - 1; ++i){
            int modifiedIndex = numChildren - getMovedChildIndex(grayCodes.get(i), grayCodes.get(i + 1))[0];
            System.out.println(children[modifiedIndex - 1]);
        }

        HashMap<String, String> movedChildren = new HashMap<String, String>();
        for(int i = 0; i < grayCodes.size() - 1; ++i){
            int[] movedChildInfo = getMovedChildIndex(grayCodes.get(i), grayCodes.get(i + 1));
            int modifiedIndex = numChildren - movedChildInfo[0];
            String childName = children[modifiedIndex - 1];
            String moveType = (movedChildInfo[1] == 0 ? "exit" : "enter");
            movedChildren.put(grayCodes.get(i + 1), childName + " " + moveType);
        }

        System.out.println();
        System.out.println("Completed table: ");
        printTable(grayCodes, children, movedChildren);
    }

    public static ArrayList<String> generateGrayCodes(int n){
        if( n <= 0 ) return new ArrayList<String>();

        ArrayList<String> grayCodes = new ArrayList<String>();
        grayCodes.add("0");
        grayCodes.add("1");

        for(int i = 2; i < (1 << n); i = i << 1){
            for (int j = i - 1 ; j >= 0 ; --j)
                grayCodes.add(grayCodes.get(j));

            for(int j = 0; j < i; ++j)
                grayCodes.set(j, "0" + grayCodes.get(j));

            for(int j = i; j < 2*i; ++j){
                grayCodes.set(j, "1" + grayCodes.get(j));
            }
        }

        return grayCodes;
    }

    public static int[] getMovedChildIndex(String s1, String s2){
        int[] answer = new int[2];
        for(int i = 0; i < s1.length(); ++i){
            if(s1.charAt(i) != s2.charAt(i)){
                answer[0] = i;
                answer[1] = Character.getNumericValue(s2.charAt(i));
                return answer;
            }
        }

        return answer;
    }

    public static String childrenInPhoto(String[] children, String grayCode){
        String answer = "";
        for(int i = 0; i < grayCode.length(); ++i){
            int digit = Integer.parseInt(grayCode.substring(i, i + 1));
            if(answer != "" && digit == 1) answer += " ";
            if(digit == 1) answer += children[children.length - i - 1];
        }
        return answer;
    }

    public static void printTable(ArrayList<String> grayCodes, String[] children, HashMap<String, String> movedChildren){
        System.out.println();
        System.out.println("Index | Gray Code | Child(ren) in Photo   | Action");

        int maxLength = 0;
        for(int i = 1; i < grayCodes.size(); ++i){
            maxLength = Math.max(maxLength, childrenInPhoto(children, grayCodes.get(i)).length());
        }

        for(int i = 1; i < grayCodes.size(); ++i){
            String line = "";
            String grayCode = grayCodes.get(i);
            line += "  " + i + (i < 10 ? "   " : "  ");

            line += "|    " + grayCode;

            line += "   | " + childrenInPhoto(children, grayCode);
            int currLength = childrenInPhoto(children, grayCode).length();
            int remainingSpaces = maxLength - currLength;
            for(int j = 0; j < remainingSpaces; ++j){
                line += " ";
            }

            line += " | " + movedChildren.get(grayCode);

            System.out.println(line);
        }
    }
}